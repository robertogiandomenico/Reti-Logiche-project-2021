# Tests

Subfolders contain output for different edge cases

| Test Name | Test Description            |
| --------- | --------------------------- |
| test0     | size=1 limit=3              |
| test1     | size=2 limit=3              |
| test2     | size=2 input length is zero |
| test3     | size=2 input length is 255  |
| test4     | size=50 limit=255           |
